<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid bg-light">
	<div class="row mt-3 bg-light justify-content-center ">
		<div id="student-information-container" class="col-lg-8 col-md-8 col-sm-10 col-xs-11 row justify-content-center bg-light"></div>
	</div>
</div>
	
