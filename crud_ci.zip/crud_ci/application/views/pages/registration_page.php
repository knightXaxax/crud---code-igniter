<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<div class="container-fluid">
	<div class="row mt-3 justify-content-center mb-5 mt-3">
		<div class="col-lg-8 col-md-8 col-sm-10 col-xs-11 row justify-content-center">
			<div id="registration-form-container" class="bg-dark border-muted shadow-lg rounded-lg mb-2 col-lg-8">
				<?php $this->load->view('forms/registration_form'); ?>
			</div>
		</div>
	</div>
</div>
	
